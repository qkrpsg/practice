package com.threeducks.practice.intro

import android.app.Activity

class IntroActivity : Activity() {

} // class :: IntroActivity